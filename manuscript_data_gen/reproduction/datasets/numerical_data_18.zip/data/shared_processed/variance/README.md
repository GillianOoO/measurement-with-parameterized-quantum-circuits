# Current variance and bias inputs

Current molecular plots contain H4 (R=1.20 A), H6 (R=3.40 A), BeH2 and N2.
They compare SRDD with OGM, SG and Derand; BeH2/N2 also include FC-IMA.
GPD appears only in the sparse/dense random-Hamiltonian comparisons.

## Files and conventions

- `supp_state_dependent_variance_by_budget.csv`: molecular SI sampling
  variances and signed deterministic biases for the selected decomposition.
- `state_dependent_variance_T3000.csv`: fixed-geometry Main Figure 4 variances.
- `state_dependent_variance_by_budget.csv`: additional fixed-schedule and
  iid-distribution quantities used by the resource renderer.
- `manifest.json`: original numerical construction audit, not a current
  figure-rebuild certificate.

Historical AGPD rows remain in some source tables for provenance; the plotter
excludes them. They are not current GPD results. Current GPD sources are ten
`data/random_sparse_dense/results/gpd_balanced/*/selected_results.csv` files.
Pauli random variances use the audited per-instance table in that results
directory; its historical GPD rows are also excluded.

Sampling variance is the variance of the complete fixed-allocation estimator,
not single-measurement iid variance. Independent rotated-diagonal settings give
`sum_i Var_rho(M_i)/T_i`; pooled Pauli schedules include coverage covariances.
Do not interchange these quantities with `T * Var(E_hat)` or iid variance.

Deterministic bias is `b = Tr[rho(H_hat-H)]`; analytic MSE is
`variance + b**2`. SI lower bars show `abs(b)` for SRDD, or the mean of five
individual `abs(b)` values for random GPD. Reflected plotting coordinates are
negative, but bar lengths and tick labels give nonnegative magnitudes.

`../presentations/supp_absolute_bias_by_budget.csv` contains 38 displayed
values. SI random panels omit T=12 for every method and bias bar because GPD
sampling variance is zero there. All original records and the full derived
random-variance summary retain T=12. Main Figure 5 is not cropped.

See [current reproduction instructions](../../../FIGURE_REPRODUCTION.md).
